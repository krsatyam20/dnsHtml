<?php
/* constructor :two types of constructor 
  => no arguments/parameters
  =>with arguments/parameters

no need to used return keyword
no need to call a function 
*/


class conExamp{
	
	/*function __construct(){
		
	echo "my first without arguments/parameters constructor";	
		
		
	}*/
	
	function msg(){
		
		echo "Without constructor function ";
	}
	
	function __construct($a){
		
	echo "my first with arguments/parameters constructor".$a;	
		
		
	}
	
	
	
	
}


$obj=new conExamp("Kumar");
$obj->msg();
?>