<?php
class vehicle{

   function persional($modelName,$modelYear,$price){
	
	echo "ModelName= " .$modelName."</br>";
	echo "Model Year= ".$modelYear."</br>";
	echo "Price=" .$price."</br>";
	
   }
}
class sportVehicle extends vehicle{
     
	 
	 
}

class coun{
	
	function __construct($a,$b){
	   echo "</br>"."Hello";
	   $c= $a+$b;
	   echo "</br>".$c;
	}
	// Note: No Need to used return keyword
	
}

$obj=new sportVehicle();

$obj->persional("h102",2019,20000);

//No need to call function 
$obj2 = new coun(12,2);

?>