<?php

//print any msg

//echo phpinfo();

echo "<h1>Hello Deepak</h1>";

//create variable

$a;

//value assign on variable

$a=10;

echo $a;

//no need to define any data type like int float char

$a=10.10;

echo $a;


$a="Saurabh";

echo $a;


$a= 30;

$b= 30;
$c= $a+$b;

echo $c;
//concinate string with variable
//concinate two string

echo "</br>"; 
echo "Add value of a and b =".$c;


$fname="kumar";
$lname="satyam";

echo "</br>";
$fullname=$fname." ".$lname;
echo $fullname;
?>