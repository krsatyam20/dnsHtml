<?php 
session_start();

echo $_SESSION['email'];
$msg="";
if(isset($_POST['imgUpload']))
{
		if(!empty($_FILES['image']['name'])){
			$imageName=time().$_FILES['image']['name'];
			$target='img/'.$imageName;
			$source=$_FILES['image']['tmp_name'];
			copy($source,$target);
		}
		else{
			
		$msg="Please select any image/File";	
		}
}
print_r($_FILES);

?>


<html>
<head>


</head>
<body>
<h1> User Photo </h1>
<h1 style="color:red;"> <?php  echo $msg; ?> </h1>
<form method="POST" enctype="multipart/form-data">
<p><input type="File" name="image" placeholder="image"/></p>
<p><input type="submit" name="imgUpload" value="Image Upload" /></p>

</form>




</body>

</html>
