<?php
session_start();
include("dbConnection.php");

//print_r($_POST);
$msg="";
if(isset($_POST['Singin'])){
	
$sql="select * from user where email='".$_POST['email']."' AND pwd='".$_POST['password']."'";	
echo $sql;

//die();	
if ($result=mysqli_query($conn,$sql))
  {
  // Return the number of rows in result set
  $rowcount=mysqli_num_rows($result);

if($rowcount>0){
	header("Location: welcome.php");
   $_SESSION['email']=$_POST['email'];
}
else {
	$msg="Email or Password is wrong";
}
  }
}
else{
$msg="Please Fill the form";	
	
}
?>

<html>
<head>


</head>
<body>
<h1> User Login </h1>
<h1 style="color:red;"> <?php  echo $msg; ?> </h1>
<form method="POST">
<p><input type="text" name="email" placeholder="Email"/></p>
<p><input type="text" name="password" placeholder="password"/></p>
<p><input type="submit" name="Singin" value="Sing up" /></p>

</form>

</body>

</html>