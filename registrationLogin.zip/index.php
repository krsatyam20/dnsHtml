<?php 

include("dbconnection.php");
$sql="create table teacher (id int(11) primary key AUTO_INCREMENT,teacher_name varchar(55))";

//$conn->query($sql);

?>

<html>

<head>
<title>


</title>

</head>
<body>
<h1><?php echo "hello" ; ?></h1> 

</body>
</html>