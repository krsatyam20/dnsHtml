<?php
//Define array
$x=array();


//store value using array
for($i=1;$i<11;$i++){
	
	$x[$i]=$i;
}

// print array
for($j=1;$j<11;$j++){
	
	echo $x[$j];
}


?>