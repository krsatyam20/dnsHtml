<?php //Array : is a collection of data and store on single variable.


//define array
// single array/ index array	
$x= array(10,20,"mango","apple");


//echo $x[0];	


foreach($x as $index=> $value){
	
	echo "[". $index."]=".$value ."</br>";
	
	
}



//associate array

$student=array("rollNo"=>"101","name"=>"Shyam","contact"=>"9205521812");

echo $student['rollNo']."</br>";


$student['rollNo']=104;
foreach($student as $index=> $value){
	
	echo "[". $index."]=".$value ."</br>";
}


$month= array("jan","feb","mar","apr");	
?>

<html>
<head>

</head>
<body>

<select>

<?php foreach($month as $index=> $val) {?>
<option value="<?php echo $val; ?>"> <?php echo $val; ?></option>
<?php } ?>

</select>

</body>

</html>


